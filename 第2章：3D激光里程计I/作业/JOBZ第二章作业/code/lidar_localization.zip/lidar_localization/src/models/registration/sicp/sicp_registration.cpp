/*
 * @Description: ICP SVD lidar odometry
 * @Author: Ge Yao
 * @Date: 2020-10-24 21:46:45
 */

#include <pcl/common/transforms.h>

#include <Eigen/Dense>

#include "glog/logging.h"


#include "lidar_localization/models/registration/sicp/scip_registration.hpp"
#include "lidar_localization/models/registration/sicp/ICP.hpp"

namespace lidar_localization {
SICP::Parameters params_;

SICPRegistration::SICPRegistration(
    const YAML::Node& node
) {
    // parse params:
    
    params_.p = node["p"].as<float>();
    params_.mu = node["mu"].as<float>();
    params_.alpha = node["alpha"].as<float>();
    params_.max_mu = node["max_mu"].as<float>();
    params_.max_icp = node["max_icp"].as<int>();
    params_.max_outer = node["max_outer"].as<int>();
    params_.max_inner = node["max_inner"].as<int>();
    params_.stop = node["stop"].as<float>();
    // params_.p = 1.0;
    // params_.mu = 10.0;
    // params_.alpha = 1.2;
    // params_.max_mu = 1e5;
    // params_.max_icp = 100;
    // params_.max_outer = 100;
    // params_.max_inner = 1;
    // params_.stop = 1e-5;
}


bool SICPRegistration::SetInputTarget(const CloudData::CLOUD_PTR& input_target) {
    input_target_ = input_target;

    return true;
}

bool SICPRegistration::ScanMatch(
    const CloudData::CLOUD_PTR& input_source, 
    const Eigen::Matrix4f& predict_pose, 
    CloudData::CLOUD_PTR& result_cloud_ptr,
    Eigen::Matrix4f& result_pose
) {
    input_source_ = input_source;

    // pre-process input source:
    CloudData::CLOUD_PTR transformed_input_source(new CloudData::CLOUD());
    pcl::transformPointCloud(*input_source_, *transformed_input_source, predict_pose);

    //
    // TODO: second option -- adapt existing implementation
    //

    // TODO: format inputs for SICP:
    // prepare normals
    pcl::PointCloud<pcl::Normal>::Ptr target_normals ( new pcl::PointCloud<pcl::Normal> );
    addNormal(input_target_, target_normals );   //计算目标点云的法向量
    
    X.resize(3,transformed_input_source->size());
    Y.resize(3,input_target_->size());
    N.resize(3,target_normals->size());

  
    for(int i = 0; i < transformed_input_source->size(); i++)
    {
        X(0,i) = transformed_input_source->points[i].x;
        X(1,i) = transformed_input_source->points[i].y;
        X(2,i) = transformed_input_source->points[i].z;
    }
    for(int i = 0; i < input_target_->size(); i++)
    {
        Y(0,i) = input_target_->points[i].x;
        Y(1,i) = input_target_->points[i].y;
        Y(2,i) = input_target_->points[i].z;
    }
    for(int i = 0; i < target_normals->size(); i++)
    {
        N(0,i) = target_normals->points[i].normal_x;
        N(1,i) = target_normals->points[i].normal_y;
        N(2,i) = target_normals->points[i].normal_z;
    }
    //处理点云，提供给SICP算法
    // TODO: SICP registration:
    Eigen::Affine3d  temp_transformation_ = SICP::point_to_point ( X, Y, params_);
    // Eigen::Affine3d  temp_transformation_ = SICP::point_to_plane ( X, Y, N, params_); // sparse ICP with normals   //会报错
 
    // set output:
    transformation_.setIdentity();
    transformation_ = temp_transformation_.matrix().cast<float>();
    result_pose = transformation_ * predict_pose;
    // 归一化
    Eigen::Quaternionf  qr(result_pose.block<3,3>(0,0));
    qr.normalize();
    Eigen::Vector3f  t  = result_pose.block<3,1>(0,3);
    result_pose.setIdentity();
    result_pose.block<3,3>(0,0) = qr.toRotationMatrix();
    result_pose.block<3,1>(0,3) = t;
    pcl::transformPointCloud(*input_source_, *result_cloud_ptr, result_pose);
    
    return true;
}

void SICPRegistration::addNormal(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud,
	       pcl::PointCloud<pcl::Normal>::Ptr normals
)
{

  pcl::search::KdTree<pcl::PointXYZ>::Ptr searchTree (new pcl::search::KdTree<pcl::PointXYZ>);
  searchTree->setInputCloud ( cloud );

  pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> normalEstimator;
  normalEstimator.setInputCloud ( cloud );
  normalEstimator.setSearchMethod ( searchTree );
  normalEstimator.setKSearch ( 15 );
  normalEstimator.compute ( *normals );
  
}

} // namespace lidar_localization