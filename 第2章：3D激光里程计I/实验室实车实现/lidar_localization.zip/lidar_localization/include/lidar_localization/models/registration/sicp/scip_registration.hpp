/*
 * @Description: SICP registration 
 * @Author: Ge Yao
 * @Date: 2021-04-24 08:46:57
 */
#ifndef LIDAR_LOCALIZATION_MODELS_REGISTRATION_SICP_REGISTRATION_HPP_
#define LIDAR_LOCALIZATION_MODELS_REGISTRATION_SICP_REGISTRATION_HPP_

#include "lidar_localization/models/registration/registration_interface.hpp"
// #include <pcl/io/ply_io.h>
// #include <pcl/io/vtk_lib_io.h>
// #include <pcl/point_types.h>
// #include <pcl/registration/icp.h>
// #include <pcl/visualization/cloud_viewer.h>
// #include <pcl/filters/filter_indices.h>
// #include <pcl/common/transforms.h>
#include <pcl/features/normal_3d.h>

namespace lidar_localization {

class SICPRegistration: public RegistrationInterface {
  public:
    SICPRegistration(const YAML::Node& node);
    void addNormal(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, pcl::PointCloud<pcl::Normal>::Ptr normals);
    bool SetInputTarget(const CloudData::CLOUD_PTR& input_target) override;
    bool ScanMatch(
      const CloudData::CLOUD_PTR& input_source, 
      const Eigen::Matrix4f& predict_pose, 
      CloudData::CLOUD_PTR& result_cloud_ptr,
      Eigen::Matrix4f& result_pose
    ) override;

  private:
    CloudData::CLOUD_PTR input_target_;
    CloudData::CLOUD_PTR input_source_;
    Eigen::Matrix4f transformation_;
    Eigen::Matrix3Xd X; // source, transformed
    Eigen::Matrix3Xd Y; // target
    Eigen::Matrix3Xd N;  // target normal

};

} // namespace lidar_localization

#endif // LIDAR_LOCALIZATION_MODELS_REGISTRATION_SICP_REGISTRATION_HPP_