# ROS Wrapper Package for gnss-ins-sim

ROS wrapper package for [gnss-ins-sim](https://github.com/Aceinna/gnss-ins-sim) including:

* [IMU Message Publisher Node](src/gnss_ins_sim_publisher_node.py)
* [IMU Message ROS Bag Recorder Node](src/gnss_ins_sim_recorder_node.py)