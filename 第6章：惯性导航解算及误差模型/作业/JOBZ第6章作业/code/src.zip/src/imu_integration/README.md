# IMU Integration

This is the ROS C++ package for odometry estimation through direct IMU measurements integration.